<?php
$con=mysqli_connect("localhost","root","","human_suspicious_activity_detection");
  ?>