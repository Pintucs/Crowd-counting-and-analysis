package com.doorsecuritysys;

public class Constants {
    public static String keyUserFireBaseId="keyUserFireBaseId";
    public static String keyUserEmail="keyUserEmail";
    public static String keyUserFirstName="keyUserFirstName";
    public static String keyUserLastName="keyUserLastName";
    public static String keyUserMobileNo="keyUserMobileNo";
    public static String keyUserGender="keyUserGender";
    public static String keyUserId="keyUserId";
    public static String keyLoginCheck="keyLoginCheck";
    public static String keyUserPic="keyUserPic";
}
